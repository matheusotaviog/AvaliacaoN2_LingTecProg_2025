package view;

import dao.DaoCursos;

public class FormUpdate {

    public static void main(String[] args) {

        DaoCursos dao = new DaoCursos();
        dao.update();

    }

}
